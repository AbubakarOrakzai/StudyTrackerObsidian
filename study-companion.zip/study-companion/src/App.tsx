import { useEffect, useState } from "react";
import { getCurrentWindow } from "@tauri-apps/api/window";
import { TitleBar } from "./components/TitleBar";
import { SubjectTabs } from "./components/SubjectTabs";
import { ChecklistPanel } from "./components/ChecklistPanel";
import { PomodoroTimer } from "./components/PomodoroTimer";
import { StatsBar } from "./components/StatsBar";
import { SettingsPanel } from "./components/SettingsPanel";
import { useStudyStore } from "./store/useStudyStore";

// Window widths: a single checklist fits the normal 380px widget width;
// side-by-side needs roughly double so neither panel gets cramped.
const SINGLE_WIDTH = 380;
const COMPARE_WIDTH = 760;
const NORMAL_HEIGHT = 560;

export default function App() {
  const widgetMode = useStudyStore((s) => s.widgetMode);
  const settings = useStudyStore((s) => s.settings);
  const activeSubjectId = useStudyStore((s) => s.activeSubjectId);
  const compareSubjectId = useStudyStore((s) => s.compareSubjectId);
  const setCompareSubject = useStudyStore((s) => s.setCompareSubject);
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    getCurrentWindow().setAlwaysOnTop(settings.alwaysOnTop);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Resize the window to fit two panels when a compare subject is set
  // (and not in widget mode, where the checklist isn't shown at all).
  useEffect(() => {
    if (widgetMode) return;
    const width = compareSubjectId ? COMPARE_WIDTH : SINGLE_WIDTH;
    getCurrentWindow().setSize({
      type: "Logical",
      width,
      height: NORMAL_HEIGHT,
    } as any);
  }, [compareSubjectId, widgetMode]);

  if (widgetMode) {
    return (
      <div className="h-screen w-screen flex flex-col bg-bg rounded-xl2 overflow-hidden border border-border">
        <TitleBar onOpenSettings={() => setShowSettings(true)} />
        <div className="flex-1 flex items-center justify-center p-2">
          <PomodoroTimer />
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen w-screen flex flex-col bg-bg relative overflow-hidden">
      <TitleBar onOpenSettings={() => setShowSettings(true)} />
      <SubjectTabs />

      <div className="flex-1 flex flex-col p-3 gap-3 overflow-hidden">
        <div className="rounded-xl2 bg-surface/40 border border-border/50 py-2">
          <PomodoroTimer />
        </div>

        <StatsBar />

        <div className="flex-1 flex gap-3 overflow-hidden">
          <div className="flex-1 min-w-0 overflow-hidden">
            <ChecklistPanel subjectId={activeSubjectId} />
          </div>

          {compareSubjectId && compareSubjectId !== activeSubjectId && (
            <>
              <div className="w-px bg-border/60 shrink-0" />
              <div className="flex-1 min-w-0 overflow-hidden">
                <ChecklistPanel
                  subjectId={compareSubjectId}
                  onClose={() => setCompareSubject(null)}
                />
              </div>
            </>
          )}
        </div>
      </div>

      {showSettings && <SettingsPanel onClose={() => setShowSettings(false)} />}
    </div>
  );
}
