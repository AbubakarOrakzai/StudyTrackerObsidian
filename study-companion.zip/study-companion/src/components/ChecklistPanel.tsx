import { useState } from "react";
import { Upload, Download, X } from "lucide-react";
import { PhaseCard } from "./PhaseCard";
import { useStudyStore } from "../store/useStudyStore";
import { parseStudyPlan, exportPlanToMarkdown } from "../lib/parseStudyPlan";

// Renders one subject's checklist. The App renders one or two of these
// side-by-side (active subject, plus an optional compare subject), so all
// state reads/writes are scoped to the given subjectId — nothing here
// reads a single global plan anymore.
export function ChecklistPanel({
  subjectId,
  onClose,
}: {
  subjectId: string;
  onClose?: () => void; // shown only in compare mode, to unpin the second panel
}) {
  const subject = useStudyStore((s) => s.subjects.find((sub) => sub.id === subjectId));
  const importPlan = useStudyStore((s) => s.importPlan);
  const overallProgress = useStudyStore((s) => s.overallProgress(subjectId));

  const [showImport, setShowImport] = useState(false);
  const [importText, setImportText] = useState("");

  if (!subject) return null;

  function handleImport() {
    if (!importText.trim()) return;
    const parsed = parseStudyPlan(importText);
    if (parsed.length > 0) {
      importPlan(subjectId, parsed);
      setShowImport(false);
      setImportText("");
    }
  }

  function handleExport() {
    const markdown = exportPlanToMarkdown(subject!.plan);
    const blob = new Blob([markdown], { type: "text/markdown" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    const dateStamp = new Date().toISOString().slice(0, 10);
    const safeTitle = subject!.title.toLowerCase().replace(/[^a-z0-9]+/g, "-");
    a.href = url;
    a.download = `${safeTitle}-${dateStamp}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex flex-col h-full min-w-0">
      <div className="flex items-center justify-between px-1 mb-2 gap-2">
        <div className="min-w-0">
          <div className="text-xs text-ink-muted uppercase tracking-wide truncate" title={subject.title}>
            {subject.title}
          </div>
          <div className="font-display text-xl font-bold" style={{ color: subject.color }}>
            {overallProgress}%
          </div>
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          <button
            onClick={handleExport}
            title="Download this subject's plan as markdown"
            className="flex items-center gap-1.5 text-xs rounded-full border border-border px-2.5 py-1.5 hover:bg-surface-hover transition-colors"
          >
            <Download size={13} />
          </button>
          <button
            onClick={() => setShowImport((v) => !v)}
            title="Import plan (replaces this subject's checklist)"
            className="flex items-center gap-1.5 text-xs rounded-full border border-border px-2.5 py-1.5 hover:bg-surface-hover transition-colors"
          >
            <Upload size={13} />
          </button>
          {onClose && (
            <button
              onClick={onClose}
              title="Remove from side-by-side view"
              className="flex items-center gap-1.5 text-xs rounded-full border border-border px-2.5 py-1.5 hover:bg-surface-hover transition-colors"
            >
              <X size={13} />
            </button>
          )}
        </div>
      </div>

      <div className="h-1.5 w-full bg-border/60 rounded-full mb-4">
        <div
          className="h-1.5 rounded-full transition-all duration-500"
          style={{ width: `${overallProgress}%`, backgroundColor: subject.color }}
        />
      </div>

      {showImport && (
        <div className="mb-3 rounded-lg border border-border bg-surface p-2 animate-pop-in">
          <textarea
            value={importText}
            onChange={(e) => setImportText(e.target.value)}
            placeholder={
              "Paste a plan using:\n# Phase 1 — Title\n## Week 1 — Title\n- Task one\n- Task two"
            }
            rows={6}
            className="w-full bg-transparent text-xs font-mono resize-none focus:outline-none placeholder:text-ink-muted/50"
          />
          <div className="flex justify-end gap-2 mt-1">
            <button
              onClick={() => setShowImport(false)}
              className="text-xs text-ink-muted hover:text-ink px-2 py-1"
            >
              Cancel
            </button>
            <button
              onClick={handleImport}
              className="text-xs bg-avocado text-bg font-semibold rounded-md px-3 py-1 hover:bg-avocado-bright"
            >
              Replace plan
            </button>
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto pr-1">
        {subject.plan.length === 0 ? (
          <p className="text-xs text-ink-muted px-1">
            No plan yet — click the upload icon to import one.
          </p>
        ) : (
          subject.plan.map((phase, i) => (
            <PhaseCard key={phase.id} subjectId={subjectId} phase={phase} defaultOpen={i === 0} />
          ))
        )}
      </div>
    </div>
  );
}
