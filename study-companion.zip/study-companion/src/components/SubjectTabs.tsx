import { useState } from "react";
import { Plus, Columns2, Trash2, Check, X } from "lucide-react";
import clsx from "clsx";
import { useStudyStore } from "../store/useStudyStore";

export function SubjectTabs() {
  const subjects = useStudyStore((s) => s.subjects);
  const activeSubjectId = useStudyStore((s) => s.activeSubjectId);
  const compareSubjectId = useStudyStore((s) => s.compareSubjectId);
  const setActiveSubject = useStudyStore((s) => s.setActiveSubject);
  const setCompareSubject = useStudyStore((s) => s.setCompareSubject);
  const addSubject = useStudyStore((s) => s.addSubject);
  const deleteSubject = useStudyStore((s) => s.deleteSubject);
  const overallProgress = useStudyStore((s) => s.overallProgress);

  const [adding, setAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  // When set, that tab shows an inline "delete this?" confirm instead of
  // its normal content — avoids a native confirm() dialog breaking the
  // app's look, and avoids one-click accidental deletion.
  const [confirmingDeleteId, setConfirmingDeleteId] = useState<string | null>(null);

  function handleAdd() {
    if (newTitle.trim()) addSubject(newTitle);
    setNewTitle("");
    setAdding(false);
  }

  function handleToggleCompare(subjectId: string) {
    setCompareSubject(compareSubjectId === subjectId ? null : subjectId);
  }

  function handleConfirmDelete(subjectId: string) {
    deleteSubject(subjectId);
    setConfirmingDeleteId(null);
  }

  const onlyOneSubject = subjects.length <= 1;

  return (
    <div className="flex items-center gap-1.5 px-2 py-2 overflow-x-auto border-b border-border/60 bg-surface/30">
      {subjects.map((subject) => {
        const isActive = subject.id === activeSubjectId;
        const isCompared = subject.id === compareSubjectId;
        const isConfirmingDelete = confirmingDeleteId === subject.id;
        const progress = overallProgress(subject.id);

        if (isConfirmingDelete) {
          return (
            <div
              key={subject.id}
              className="flex items-center gap-1.5 shrink-0 rounded-full pl-3 pr-1.5 py-1 text-xs border border-coral bg-coral/10"
            >
              <span className="text-coral font-medium">Delete "{subject.title}"?</span>
              <button
                onClick={() => handleConfirmDelete(subject.id)}
                title="Confirm delete"
                className="rounded-full p-1 bg-coral text-bg hover:bg-coral-soft transition-colors"
              >
                <Check size={11} />
              </button>
              <button
                onClick={() => setConfirmingDeleteId(null)}
                title="Cancel"
                className="rounded-full p-1 hover:bg-surface-hover transition-colors"
              >
                <X size={11} />
              </button>
            </div>
          );
        }

        return (
          <div
            key={subject.id}
            className={clsx(
              "group flex items-center gap-1 shrink-0 rounded-full pl-3 pr-1.5 py-1 text-xs border transition-colors cursor-pointer",
              isActive
                ? "border-transparent"
                : "border-border text-ink-muted hover:bg-surface-hover"
            )}
            style={isActive ? { backgroundColor: subject.color, color: "#14151A" } : undefined}
            onClick={() => setActiveSubject(subject.id)}
            title={subject.title}
          >
            <span className="max-w-[110px] truncate font-medium">{subject.title}</span>
            <span className="font-mono opacity-80">{progress}%</span>

            {!isActive && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleToggleCompare(subject.id);
                }}
                title={isCompared ? "Remove from side-by-side view" : "Show side-by-side with active subject"}
                className={clsx(
                  "ml-0.5 rounded-full p-1 transition-colors",
                  isCompared ? "bg-coral text-bg" : "hover:bg-surface-hover"
                )}
              >
                <Columns2 size={11} />
              </button>
            )}

            {!onlyOneSubject && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setConfirmingDeleteId(subject.id);
                }}
                title="Delete this subject"
                className={clsx(
                  "rounded-full p-1 transition-colors opacity-0 group-hover:opacity-100",
                  isActive ? "hover:bg-bg/20" : "hover:bg-coral/20 hover:text-coral"
                )}
              >
                <Trash2 size={11} />
              </button>
            )}
          </div>
        );
      })}

      {adding ? (
        <input
          autoFocus
          value={newTitle}
          onChange={(e) => setNewTitle(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") handleAdd();
            if (e.key === "Escape") setAdding(false);
          }}
          onBlur={handleAdd}
          placeholder="Subject name…"
          className="shrink-0 w-32 rounded-full bg-surface border border-border px-3 py-1 text-xs focus:outline-none focus:border-avocado"
        />
      ) : (
        <button
          onClick={() => setAdding(true)}
          title="Add a new subject"
          className="shrink-0 rounded-full border border-dashed border-border p-1.5 text-ink-muted hover:bg-surface-hover hover:text-ink transition-colors"
        >
          <Plus size={13} />
        </button>
      )}
    </div>
  );
}
