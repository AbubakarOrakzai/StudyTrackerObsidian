import clsx from "clsx";
import type { Task } from "../types";

// Splits "**Time:** 2h Reading" into [bold "Time:", normal " 2h Reading"]
// so simple **bold** markdown in task titles renders instead of showing
// literal asterisks. Anything more complex than **bold** is left as-is.
function renderTitle(title: string) {
  const parts = title.split(/(\*\*[^*]+\*\*)/g).filter(Boolean);
  return parts.map((part, i) => {
    if (part.startsWith("**") && part.endsWith("**")) {
      return (
        <strong key={i} className="font-semibold text-ink">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return <span key={i}>{part}</span>;
  });
}

export function TaskRow({
  task,
  onToggle,
}: {
  task: Task;
  onToggle: () => void;
}) {
  return (
    <label className="flex items-start gap-2.5 py-1.5 px-2 rounded-lg hover:bg-surface-hover cursor-pointer group">
      <input
        type="checkbox"
        className="task-checkbox mt-0.5"
        checked={task.done}
        onChange={onToggle}
      />
      <span
        className={clsx(
          "text-sm leading-snug transition-colors",
          task.done ? "text-ink-muted line-through" : "text-ink group-hover:text-ink"
        )}
      >
        {renderTitle(task.title)}
      </span>
    </label>
  );
}
