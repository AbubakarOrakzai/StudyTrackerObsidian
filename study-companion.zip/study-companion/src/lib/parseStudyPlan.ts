import type { StudyPlan, Phase, Week, Day, Task } from "../types";

// Expected input format (Markdown), designed to match how you already
// write these plans:
//
// # Phase 1 — Electronics & Embedded Foundations
// ## Week 1 — Electronics core + first circuits
// - Learn Ohm's Law, components, reading schematics
// - Project: LED blink
// ### Day 1
// - **Time:** 2h Reading / 2h Practice
// - **Key Concept:** Pixels as arrays
// ### Day 2
// - **Task:** Implement a script to load a color image
// ## Week 2 — MOSFETs, PWM, motors
// - ...
// # Phase 2 — ...
//
// Rules:
//   "# "   -> starts a new Phase
//   "## "  -> starts a new Week within the current Phase
//   "### " -> starts a new Day within the current Week (optional level —
//             a Week can have loose tasks with no Day, Day-grouped tasks,
//             or both)
//   "- "   -> a Task within the current Day if one is open, otherwise
//             directly under the current Week (also accepts "* " and
//             "- [ ] ")
// Anything else is ignored, so pasting extra prose/headers won't break it.
export function parseStudyPlan(markdown: string): StudyPlan {
  const lines = markdown.split("\n");
  const plan: StudyPlan = [];

  let currentPhase: Phase | null = null;
  let currentWeek: Week | null = null;
  let currentDay: Day | null = null;
  let uid = 0;
  const id = (prefix: string) => `${prefix}-${uid++}`;

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;

    // "### " must be checked before "## " / "# " since it also starts
    // with those prefixes.
    if (line.startsWith("### ")) {
      if (!currentWeek) {
        if (!currentPhase) {
          currentPhase = { id: id("phase"), label: "Untitled Phase", weeks: [] };
          plan.push(currentPhase);
        }
        currentWeek = { id: id("week"), label: "Untitled Week", tasks: [], days: [] };
        currentPhase.weeks.push(currentWeek);
      }
      currentDay = { id: id("day"), label: line.replace(/^###\s+/, ""), tasks: [] };
      currentWeek.days.push(currentDay);
      continue;
    }

    if (line.startsWith("## ")) {
      if (!currentPhase) {
        currentPhase = { id: id("phase"), label: "Untitled Phase", weeks: [] };
        plan.push(currentPhase);
      }
      currentWeek = { id: id("week"), label: line.replace(/^##\s+/, ""), tasks: [], days: [] };
      currentPhase.weeks.push(currentWeek);
      currentDay = null;
      continue;
    }

    if (line.startsWith("# ") && !line.startsWith("## ")) {
      currentPhase = { id: id("phase"), label: line.replace(/^#\s+/, ""), weeks: [] };
      plan.push(currentPhase);
      currentWeek = null;
      currentDay = null;
      continue;
    }

    const taskMatch = line.match(/^[-*]\s*(?:\[[ xX]\]\s*)?(.+)$/);
    if (taskMatch) {
      if (!currentWeek) {
        if (!currentPhase) {
          currentPhase = { id: id("phase"), label: "Untitled Phase", weeks: [] };
          plan.push(currentPhase);
        }
        currentWeek = { id: id("week"), label: "Untitled Week", tasks: [], days: [] };
        currentPhase.weeks.push(currentWeek);
      }
      const done = /^-\s*\[[xX]\]/.test(line);
      const task: Task = { id: id("task"), title: taskMatch[1].trim(), done };
      // A task goes into the currently open Day if one exists, otherwise
      // directly onto the Week.
      (currentDay ? currentDay.tasks : currentWeek.tasks).push(task);
    }
  }

  return plan;
}

// The inverse of parseStudyPlan: turns the current Phase[] state back into
// the same "# Phase / ## Week / ### Day / - [ ] Task" markdown format, so
// a plan (including current check-off progress) can be backed up or
// shared, then re-imported later with parseStudyPlan.
export function exportPlanToMarkdown(plan: StudyPlan): string {
  const lines: string[] = [];

  for (const phase of plan) {
    lines.push(`# ${phase.label}`);
    for (const week of phase.weeks) {
      lines.push(`## ${week.label}`);
      for (const task of week.tasks) {
        lines.push(`- [${task.done ? "x" : " "}] ${task.title}`);
      }
      for (const day of week.days) {
        lines.push(`### ${day.label}`);
        for (const task of day.tasks) {
          lines.push(`- [${task.done ? "x" : " "}] ${task.title}`);
        }
      }
    }
    lines.push(""); // blank line between phases for readability
  }

  return lines.join("\n").trim() + "\n";
}
