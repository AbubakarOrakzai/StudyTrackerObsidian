import { create } from "zustand";
import { persist } from "zustand/middleware";
import type {
  Subject,
  StudyPlan,
  Settings,
  PomodoroLogEntry,
  CompletionLogEntry,
} from "../types";
import { defaultSubjects } from "../data/defaultSubjects";
import { appendObsidianLog } from "../lib/obsidian";

const SUBJECT_COLORS = ["#8FAE6E", "#E8875B", "#6FA8DC", "#C99FE0", "#E0C568"];

interface StudyState {
  subjects: Subject[];
  activeSubjectId: string; // which subject's panel is the "main" one
  compareSubjectId: string | null; // a second subject shown side-by-side, or null

  settings: Settings;
  pomodoroLogs: PomodoroLogEntry[];
  completionLogs: CompletionLogEntry[];
  widgetMode: boolean;

  // Subject management
  addSubject: (title: string) => void;
  renameSubject: (subjectId: string, title: string) => void;
  deleteSubject: (subjectId: string) => void;
  setActiveSubject: (subjectId: string) => void;
  setCompareSubject: (subjectId: string | null) => void;

  // Checklist actions, all scoped to a subject
  toggleTask: (subjectId: string, weekId: string, taskId: string) => void;
  importPlan: (subjectId: string, plan: StudyPlan) => void;

  // Settings actions
  updateSettings: (patch: Partial<Settings>) => void;

  // Pomodoro/logging actions
  logPomodoroSession: (taskName: string, minutes: number) => void;

  // Widget mode
  setWidgetMode: (on: boolean) => void;

  // Derived stats
  overallProgress: (subjectId: string) => number;
  weekProgress: (subjectId: string, weekId: string) => number;
  focusedMinutesThisWeek: () => number;
  tasksCompletedThisWeek: () => number;
}

function startOfWeekISO(): string {
  const now = new Date();
  const day = now.getDay();
  const diff = now.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(now.setDate(diff));
  monday.setHours(0, 0, 0, 0);
  return monday.toISOString();
}

function findSubject(subjects: Subject[], id: string) {
  return subjects.find((s) => s.id === id);
}

export const useStudyStore = create<StudyState>()(
  persist(
    (set, get) => ({
      subjects: defaultSubjects,
      activeSubjectId: defaultSubjects[0].id,
      compareSubjectId: null,

      settings: {
        vaultPath: "",
        logFileName: "Study Log.md",
        obsidianEnabled: false,
        pomodoroWorkMin: 25,
        pomodoroBreakMin: 5,
        alwaysOnTop: false,
        soundEnabled: true,
      },
      pomodoroLogs: [],
      completionLogs: [],
      widgetMode: false,

      addSubject: (title) => {
        const trimmed = title.trim();
        if (!trimmed) return;
        const newSubject: Subject = {
          id: crypto.randomUUID(),
          title: trimmed,
          color: SUBJECT_COLORS[get().subjects.length % SUBJECT_COLORS.length],
          plan: [],
        };
        set((state) => ({
          subjects: [...state.subjects, newSubject],
          activeSubjectId: newSubject.id,
        }));
      },

      renameSubject: (subjectId, title) => {
        const trimmed = title.trim();
        if (!trimmed) return;
        set((state) => ({
          subjects: state.subjects.map((s) =>
            s.id === subjectId ? { ...s, title: trimmed } : s
          ),
        }));
      },

      deleteSubject: (subjectId) => {
        set((state) => {
          const remaining = state.subjects.filter((s) => s.id !== subjectId);
          // Never allow zero subjects — a lone leftover subject is kept.
          const subjects = remaining.length > 0 ? remaining : state.subjects;
          const activeSubjectId =
            state.activeSubjectId === subjectId
              ? subjects[0].id
              : state.activeSubjectId;
          const compareSubjectId =
            state.compareSubjectId === subjectId ? null : state.compareSubjectId;
          return { subjects, activeSubjectId, compareSubjectId };
        });
      },

      setActiveSubject: (subjectId) => set({ activeSubjectId: subjectId }),

      setCompareSubject: (subjectId) => set({ compareSubjectId: subjectId }),

      toggleTask: (subjectId, weekId, taskId) => {
        let toggledOn = false;
        let taskTitle = "";
        let weekLabel = "";
        let subjectTitle = "";

        set((state) => ({
          subjects: state.subjects.map((subject) => {
            if (subject.id !== subjectId) return subject;
            subjectTitle = subject.title;
            return {
              ...subject,
              plan: subject.plan.map((phase) => ({
                ...phase,
                weeks: phase.weeks.map((w) => {
                  if (w.id !== weekId) return w;
                  weekLabel = w.label;

                  const toggle = (t: { id: string; title: string; done: boolean }) => {
                    if (t.id !== taskId) return t;
                    toggledOn = !t.done;
                    taskTitle = t.title;
                    return { ...t, done: !t.done };
                  };

                  return {
                    ...w,
                    tasks: w.tasks.map(toggle),
                    days: w.days.map((d) => ({ ...d, tasks: d.tasks.map(toggle) })),
                  };
                }),
              })),
            };
          }),
        }));

        if (toggledOn) {
          const entry: CompletionLogEntry = {
            id: crypto.randomUUID(),
            date: new Date().toISOString().slice(0, 10),
            label: `[${subjectTitle}] ${weekLabel} - ${taskTitle}`,
            timestamp: Date.now(),
          };
          set((state) => ({
            completionLogs: [...state.completionLogs, entry],
          }));

          const { settings } = get();
          if (settings.obsidianEnabled && settings.vaultPath) {
            appendObsidianLog(settings, {
              type: "completion",
              date: entry.date,
              text: entry.label,
            });
          }
        }
      },

      importPlan: (subjectId, plan) =>
        set((state) => ({
          subjects: state.subjects.map((s) =>
            s.id === subjectId ? { ...s, plan } : s
          ),
        })),

      updateSettings: (patch) =>
        set((state) => ({ settings: { ...state.settings, ...patch } })),

      logPomodoroSession: (taskName, minutes) => {
        const activeSubject = findSubject(get().subjects, get().activeSubjectId);
        const label = activeSubject
          ? `[${activeSubject.title}] ${taskName || "Untitled session"}`
          : taskName || "Untitled session";

        const entry: PomodoroLogEntry = {
          id: crypto.randomUUID(),
          date: new Date().toISOString().slice(0, 10),
          taskName: label,
          minutes,
          timestamp: Date.now(),
        };
        set((state) => ({ pomodoroLogs: [...state.pomodoroLogs, entry] }));

        const { settings } = get();
        if (settings.obsidianEnabled && settings.vaultPath) {
          appendObsidianLog(settings, {
            type: "pomodoro",
            date: entry.date,
            text: `${minutes}min on "${label}"`,
          });
        }
      },

      setWidgetMode: (on) => set({ widgetMode: on }),

      overallProgress: (subjectId) => {
        const subject = findSubject(get().subjects, subjectId);
        if (!subject) return 0;
        const all = subject.plan.flatMap((p) =>
          p.weeks.flatMap((w) => [...w.tasks, ...w.days.flatMap((d) => d.tasks)])
        );
        if (all.length === 0) return 0;
        return Math.round((all.filter((t) => t.done).length / all.length) * 100);
      },

      weekProgress: (subjectId, weekId) => {
        const subject = findSubject(get().subjects, subjectId);
        if (!subject) return 0;
        const week = subject.plan.flatMap((p) => p.weeks).find((w) => w.id === weekId);
        if (!week) return 0;
        const all = [...week.tasks, ...week.days.flatMap((d) => d.tasks)];
        if (all.length === 0) return 0;
        return Math.round((all.filter((t) => t.done).length / all.length) * 100);
      },

      focusedMinutesThisWeek: () => {
        const start = new Date(startOfWeekISO()).getTime();
        return get()
          .pomodoroLogs.filter((l) => l.timestamp >= start)
          .reduce((sum, l) => sum + l.minutes, 0);
      },

      tasksCompletedThisWeek: () => {
        const start = new Date(startOfWeekISO()).getTime();
        return get().completionLogs.filter((l) => l.timestamp >= start).length;
      },
    }),
    {
      name: "study-companion-storage",
      version: 3, // v1: single `plan`. v2: `subjects[]`. v3: weeks gained `days[]`.
      migrate: (persistedState: any, version) => {
        let state = persistedState;

        // v1 -> v2: wrap an old single `plan` into one subject.
        if (version < 2 && state?.plan) {
          const migratedSubject: Subject = {
            id: crypto.randomUUID(),
            title: "My Study Plan",
            color: SUBJECT_COLORS[0],
            plan: state.plan,
          };
          state = {
            ...state,
            subjects: [migratedSubject],
            activeSubjectId: migratedSubject.id,
            compareSubjectId: null,
            plan: undefined,
          };
        }

        // v2 -> v3: every Week now needs a `days` array. Backfill it on
        // any week that predates this update instead of crashing.
        if (version < 3 && Array.isArray(state?.subjects)) {
          state = {
            ...state,
            subjects: state.subjects.map((subject: Subject) => ({
              ...subject,
              plan: subject.plan.map((phase) => ({
                ...phase,
                weeks: phase.weeks.map((w: any) => ({
                  ...w,
                  days: Array.isArray(w.days) ? w.days : [],
                })),
              })),
            })),
          };
        }

        return state;
      },
    }
  )
);
