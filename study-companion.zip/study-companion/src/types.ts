// The whole study plan is Phases -> Weeks -> Tasks, matching how you
// actually structure your roadmaps (Phase 1, Week 1, checklist items).

export interface Task {
  id: string;
  title: string;
  done: boolean;
}

// An optional grouping level under a Week — e.g. "Day 1", "Session A".
// A Week can have loose tasks directly on it (no ### used), Day-grouped
// tasks (### used), or both at once.
export interface Day {
  id: string;
  label: string;
  tasks: Task[];
}

export interface Week {
  id: string;
  label: string; // e.g. "Week 3 — STM32 bootstrap"
  tasks: Task[]; // tasks not under any Day (bullets directly under ##)
  days: Day[]; // tasks grouped under a ### heading
}

export interface Phase {
  id: string;
  label: string; // e.g. "Phase 1 — Electronics & Embedded Foundations"
  weeks: Week[];
}

export type StudyPlan = Phase[];

// A Subject is a whole study track (e.g. "Drone Engineering",
// "Digital Image Processing" from a textbook). Each has its own
// independent Phase -> Week -> Task plan, so different subjects don't
// share progress, phases, or weeks with each other.
export interface Subject {
  id: string;
  title: string; // e.g. "Digital Image Processing (Gonzalez & Woods)"
  color: string; // a small accent color so tabs/panels are visually distinct
  plan: StudyPlan;
}

export interface PomodoroLogEntry {
  id: string;
  date: string; // ISO date, e.g. 2026-08-01
  taskName: string;
  minutes: number;
  timestamp: number;
}

export interface CompletionLogEntry {
  id: string;
  date: string;
  label: string; // "Week 2 - MOSFET Motor Control"
  timestamp: number;
}

export interface Settings {
  vaultPath: string; // absolute path to the Obsidian vault
  logFileName: string; // e.g. "Study Log.md"
  obsidianEnabled: boolean;
  pomodoroWorkMin: number;
  pomodoroBreakMin: number;
  alwaysOnTop: boolean;
  soundEnabled: boolean;
}
